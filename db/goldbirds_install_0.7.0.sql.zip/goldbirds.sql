SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


CREATE TABLE IF NOT EXISTS `activitydata` (
  `adid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `aid` int(11) NOT NULL COMMENT '活动ID',
  `ojaccount` varchar(128) NOT NULL COMMENT 'OJ用户名',
  `data` text COMMENT '注册信息',
  `state` smallint(6) NOT NULL DEFAULT '0' COMMENT '审核状态（0-待审核，1-拒绝，2-通过）',
  `regtime` datetime NOT NULL COMMENT '注册时间',
  PRIMARY KEY (`adid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='注册信息' AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `activitylist` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '活动ID',
  `title` varchar(200) NOT NULL COMMENT '活动名称',
  `desc` text COMMENT '活动内容描述',
  `addtime` datetime NOT NULL COMMENT '添加时间',
  `deadline` datetime NOT NULL COMMENT '截止报名时间',
  `form` varchar(10000) DEFAULT NULL COMMENT '报名表单格式',
  `isinner` smallint(6) NOT NULL DEFAULT '0' COMMENT '是否只允许队员可见（1-是，0-否）',
  `ispublic` smallint(6) NOT NULL DEFAULT '0' COMMENT '注册信息是否公开（0-否，1-是）',
  `isneedreview` smallint(6) NOT NULL DEFAULT '0' COMMENT '是否需要审核（0-否 ,1-是）',
  `adminuid` int(11) NOT NULL DEFAULT '0' COMMENT '管理者UID',
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='活动列表' AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `codepool` (
  `codeid` int(11) NOT NULL AUTO_INCREMENT COMMENT '代码ID',
  `k` varchar(8) NOT NULL COMMENT 'key键',
  `submittime` datetime NOT NULL COMMENT '提交时间',
  `tag` varchar(32) DEFAULT NULL COMMENT '左侧标签',
  `code` text NOT NULL COMMENT '代码内容',
  `ojaccount` varchar(32) DEFAULT NULL COMMENT '提交时的OJ账号',
  `ip` varchar(32) DEFAULT NULL COMMENT '客户端IP',
  PRIMARY KEY (`codeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='码池表' AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `contest` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '比赛ID',
  `holdtime` date NOT NULL COMMENT '比赛日期',
  `site` varchar(128) NOT NULL COMMENT '地点',
  `university` varchar(128) NOT NULL COMMENT '举办学校',
  `type` int(2) NOT NULL COMMENT '类型，0-WF，1-Regional，2-省赛',
  `medal` int(2) NOT NULL COMMENT '奖牌，0-金牌，1-银牌，2-铜牌，3-鼓励奖，4-旅游队',
  `title` varchar(32) DEFAULT NULL COMMENT '其它附加奖项',
  `ranking` int(11) DEFAULT NULL COMMENT '名次',
  `team` varchar(64) NOT NULL COMMENT '队名',
  `leader` int(11) NOT NULL COMMENT '队长ID',
  `teamer1` int(11) NOT NULL COMMENT '队员ID',
  `teamer2` int(11) NOT NULL COMMENT '队员ID',
  `pic1` varchar(255) DEFAULT NULL COMMENT '图1',
  `pic2` varchar(255) DEFAULT NULL COMMENT '图2',
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `news` (
  `nid` int(11) NOT NULL AUTO_INCREMENT COMMENT '新闻ID',
  `title` varchar(200) NOT NULL COMMENT '标题',
  `content` text COMMENT '内容',
  `author` int(11) NOT NULL COMMENT '作者ID',
  `createtime` datetime NOT NULL COMMENT '发布时间',
  `category` varchar(20) NOT NULL COMMENT '类别',
  `top` smallint(6) NOT NULL DEFAULT '0' COMMENT '是否置顶，1是，0否',
  `permission` smallint(6) NOT NULL DEFAULT '0' COMMENT '是否所有人可见，0是，其它否',
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='新闻表' AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ojhistory` (
  `vid` int(11) NOT NULL COMMENT '排序ID',
  `sortid` int(11) NOT NULL DEFAULT '10' COMMENT '排序ID（越大越靠前）',
  `mainname` varchar(16) NOT NULL COMMENT '主名称',
  `devname` varchar(16) DEFAULT NULL COMMENT '开发代号',
  `introduce` text COMMENT '介绍',
  `photos` text COMMENT '图，逗号分隔',
  `titles` text COMMENT '图标题，BASE64编码，逗号分隔',
  `descs` text COMMENT '图描述，BASE64编码，逗号分隔',
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='oj历史表';

CREATE TABLE IF NOT EXISTS `person` (
  `uid` int(10) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `chsname` varchar(32) NOT NULL COMMENT '中文姓名',
  `engname` varchar(64) DEFAULT NULL COMMENT '姓名拼音',
  `email` varchar(255) DEFAULT NULL COMMENT 'E-mail',
  `phone` varchar(20) DEFAULT NULL COMMENT '电话',
  `address` varchar(255) DEFAULT NULL COMMENT '现所在地',
  `sex` int(1) NOT NULL DEFAULT '0' COMMENT '性别，0-男，1-女',
  `grade` int(10) unsigned DEFAULT NULL COMMENT '年级',
  `introduce` varchar(1024) DEFAULT NULL COMMENT '简要介绍',
  `detail` text COMMENT '详细自我介绍',
  `photo` varchar(255) DEFAULT NULL COMMENT '个人照片',
  `ojaccount` varchar(32) DEFAULT NULL COMMENT '关联OJ账号',
  `group` int(2) unsigned NOT NULL DEFAULT '0' COMMENT '组别，0-队员，1-队员管理员，2-教练，9-根用户',
  `luckycode` varchar(16) DEFAULT NULL COMMENT '邀请码',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `luckycode` (`luckycode`) USING BTREE,
  UNIQUE KEY `ojaccount` (`ojaccount`) USING BTREE
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

INSERT INTO `person` (`uid`, `chsname`, `engname`, `email`, `phone`, `address`, `sex`, `grade`, `introduce`, `detail`, `photo`, `ojaccount`, `group`, `luckycode`) VALUES
(0, ' ', ' ', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, ' ', 0, 'nouseaccount0000'),
(1, 'root', 'root', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 'iloveacmiloveacm');

CREATE TABLE IF NOT EXISTS `setting` (
  `k` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL COMMENT '后台显示的名称',
  `v` text,
  `desc` varchar(255) DEFAULT NULL COMMENT '描述',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '类型，0-布尔，1-文本，2-文本（不转义）',
  UNIQUE KEY `k` (`k`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='参数表';

INSERT INTO `setting` (`k`, `name`, `v`, `desc`, `type`) VALUES
('config_lock_person_introduce', '设置-禁止修改个人简介', '0', '是否锁定个人简要介绍', 0),
('config_title', '通用-浏览器标题', 'Our ACM/ICPC Training Group', '浏览器标题处显示的文本', 1),
('home_chs_header', '首页-上方中文标题', '我们的ACM-ICPC集训队', '首页上方的中文标题（队名）', 2),
('home_eng_header', '首页-上方英文标题', 'Our ACM-ICPC Training Team', '首页上方的英文标题（队名）', 2),
('home_additional_title', '首页-上方附加标题', '荣誉榜', '首页上方队伍名称下面的附加标题', 2),
('home_mainarea', '首页-下方区域HTML代码', '  <div class="marketing">\n    <h1>This is a team with miracles.</h1>\n    <p class="marketing-byline">We firmly believe that hero continues !</p>\n        <hr class="soften">\n        <h2>Keep trying, keep going !</h2>\n  </div>\n', '首页奖牌数量下方至页脚上方的区域HTML代码', 2),
('config_contest_sort', '设置-获奖记录排序方法', '1', '设置每个赛季中比赛获奖记录（除World Fianl外）中的排序方法，Yes-按奖项，比赛时间依次排序，No-按比赛时间，奖项依次排序', 0),
('footer_additional_code', '页脚-附加代码', NULL, 'Footer区域附加HTML代码，可用于流量分析统计代码的添加等', 2),
('config_recent_days', '设置-首页显示最近获奖的天数', '6', '设置首页中展示最近获奖记录的天数，例如设置成1天，则展示时间为比赛获奖日期当天至下一天24时。', 1),
('config_contest_default_show', '设置-获奖记录默认展示样式', '1', '配置获奖记录默认的默认展示样式，Yes-酷炫版，No-表单版', 0),
('config_show_recent_contest', '设置-首页是否显示最近获奖记录', '0', '是否在首页中部奖牌数上方显示最近获奖记录的提醒', 0),
('we_icpc_introduce', '我们-ICPC简介内容', '（介绍ACM-ICPC。具体内容可到后台更改。）', '设置“我们”页面中ACM-ICPC赛事简介的内容，可为空，HTML代码。', 2),
('we_team_introduce', '我们-ICPC集训队简介', '（介绍本校的ACM-ICPC集训队。具体内容可到后台更改。）', '设置“我们”页面中ACM-ICPC集训队简介的内容，可为空，HTML代码。', 2),
('config_smtp_account', '设置-SMTP邮箱账号', 'username@ekszz.com', '用来发送邮件的SMTP邮箱账号，全称，如：acmicpc@ekszz.com', 2),
('config_smtp_fromname', '设置-SMTP发送者名称', 'OurACM', '设置SMTP发送的邮件中的发送者描述', 2),
('config_smtp_host', '设置-SMTP服务器', 'smtp.ekszz.com', '设置SMTP服务器', 2),
('config_smtp_needauth', '设置-SMTP服务器是否需要认证', '1', 'SMTP服务器是否需要认证才能使用，true-是，false-否', 0),
('config_smtp_username', '设置-SMTP服务器用户名', 'username', '在SMTP需要认证的情况下有效，SMTP服务器认证用户名。', 2),
('config_smtp_password', '设置-SMTP服务器密码', 'password', '在SMTP服务器需要认证的情况下有效，SMTP服务器密码。', 2),
('config_invite_title', '设置-邀请邮件标题', 'OurACM邀请你注册', '设置邀请邮件的标题。', 1),
('config_invite_content', '设置-邀请邮件正文内容', '亲爱的{chsname}：\nOurACM邀请你前来注册，快回来看看ACM/ICPC队的变化吧~~\n\n你的邀请码：{code}\n注册网址：{url}\n\n期待你的加入！\n\n\n自动发送的邮件，请勿直接回复。\nPowered by OurACM.\n', '设置邀请邮件的正文内容，其中{chsname}转义成队员中文名字，{engname}转义为队员英文姓名，{code}转义为相应的邀请码，{url}自动转义为注册网址。', 2),
('codepool_exptime', '码池-代码保留时间', '2592000', '码池功能中用户提交的代码保留的时间，单位为秒。', 2),
('codepool_maxlength', '码池-单个代码最大长度', '32768', '码池功能中单个代码允许提交的最大长度，单位字节。', 2),
('codepool_maxperip', '码池-单IP每24小时最大提交量', '200', '码池功能中，每个IP地址24小时内最大提交的代码数量。该值用予防止机器人提交。', 2);

CREATE TABLE IF NOT EXISTS `talk` (
  `tid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'TalkID',
  `ptid` int(11) NOT NULL COMMENT '首层TalkID',
  `ojaccount` varchar(32) NOT NULL COMMENT 'OJ账号',
  `title` varchar(200) NOT NULL COMMENT '标题',
  `content` text COMMENT '内容',
  `createtime` datetime NOT NULL COMMENT '提交时间',
  `problemid` int(11) DEFAULT NULL COMMENT 'OJ题目ID',
  `lft` int(11) NOT NULL COMMENT '预排序遍历树-左值',
  `rgt` int(11) NOT NULL COMMENT '预排序遍历树-右值',
  `ip` varchar(40) DEFAULT NULL COMMENT '客户IP地址',
  PRIMARY KEY (`tid`),
  KEY `ptid` (`ptid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Talk模块表' AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
