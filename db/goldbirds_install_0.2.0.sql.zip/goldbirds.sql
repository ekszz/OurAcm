SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


CREATE TABLE IF NOT EXISTS `contest` (
  `cid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '比赛ID',
  `holdtime` date NOT NULL COMMENT '比赛日期',
  `site` varchar(128) NOT NULL COMMENT '地点',
  `university` varchar(128) NOT NULL COMMENT '举办学校',
  `type` int(2) NOT NULL COMMENT '类型，0-WF，1-Regional，2-省赛',
  `medal` int(2) NOT NULL COMMENT '奖牌，0-金牌，1-银牌，2-铜牌，3-鼓励奖',
  `title` varchar(32) DEFAULT NULL COMMENT '其它附加奖项',
  `ranking` int(11) DEFAULT NULL COMMENT '名次',
  `team` varchar(64) NOT NULL COMMENT '队名',
  `leader` int(11) NOT NULL COMMENT '队长ID',
  `teamer1` int(11) NOT NULL COMMENT '队员ID',
  `teamer2` int(11) NOT NULL COMMENT '队员ID',
  `pic1` varchar(255) DEFAULT NULL COMMENT '图1',
  `pic2` varchar(255) DEFAULT NULL COMMENT '图2',
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `news` (
  `nid` int(11) NOT NULL AUTO_INCREMENT COMMENT '新闻ID',
  `title` varchar(200) NOT NULL COMMENT '标题',
  `content` text COMMENT '内容',
  `author` int(11) NOT NULL COMMENT '作者ID',
  `createtime` datetime NOT NULL COMMENT '发布时间',
  `category` varchar(20) NOT NULL COMMENT '类别',
  `top` smallint(6) NOT NULL DEFAULT '0' COMMENT '是否置顶，1是，0否',
  `permission` smallint(6) NOT NULL DEFAULT '0' COMMENT '是否所有人可见，0是，其它否',
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='新闻表' AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `ojhistory` (
  `vid` int(11) NOT NULL COMMENT '排序ID',
  `sortid` int(11) NOT NULL DEFAULT '10' COMMENT '排序ID（越大越靠前）',
  `mainname` varchar(16) NOT NULL COMMENT '主名称',
  `devname` varchar(16) DEFAULT NULL COMMENT '开发代号',
  `introduce` text COMMENT '介绍',
  `photos` text COMMENT '图，逗号分隔',
  `titles` text COMMENT '图标题，BASE64编码，逗号分隔',
  `descs` text COMMENT '图描述，BASE64编码，逗号分隔',
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='oj历史表';

CREATE TABLE IF NOT EXISTS `person` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `chsname` varchar(32) NOT NULL COMMENT '中文姓名',
  `engname` varchar(64) DEFAULT NULL COMMENT '姓名拼音',
  `email` varchar(255) DEFAULT NULL COMMENT 'E-mail',
  `phone` varchar(20) DEFAULT NULL COMMENT '电话',
  `address` varchar(255) DEFAULT NULL COMMENT '现所在地',
  `sex` int(1) NOT NULL DEFAULT '0' COMMENT '性别，0-男，1-女',
  `grade` int(10) unsigned DEFAULT NULL COMMENT '年级',
  `introduce` varchar(1024) DEFAULT NULL COMMENT '简要介绍',
  `detail` text COMMENT '详细自我介绍',
  `photo` varchar(255) DEFAULT NULL COMMENT '个人照片',
  `ojaccount` varchar(32) DEFAULT NULL COMMENT '关联OJ账号',
  `group` int(2) unsigned NOT NULL DEFAULT '0' COMMENT '组别，0-队员，1-队员管理员，2-教练，9-根用户',
  `luckycode` varchar(16) DEFAULT NULL COMMENT '邀请码',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `luckycode` (`luckycode`),
  UNIQUE KEY `ojaccount` (`ojaccount`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

INSERT INTO `person` (`uid`, `chsname`, `engname`, `email`, `phone`, `address`, `sex`, `grade`, `introduce`, `detail`, `photo`, `ojaccount`, `group`, `luckycode`) VALUES
(0, ' ', ' ', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, ' ', 0, 'nouseaccount0000'),
(1, 'root', 'root', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 'iloveacmiloveacm');

CREATE TABLE IF NOT EXISTS `setting` (
  `k` varchar(64) NOT NULL,
  `name` varchar(100) NOT NULL COMMENT '后台显示的名称',
  `v` text,
  `desc` varchar(255) DEFAULT NULL COMMENT '描述',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT '类型，0-布尔，1-文本，2-文本（不转义）',
  UNIQUE KEY `k` (`k`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='参数表';

INSERT INTO `setting` (`k`, `name`, `v`, `desc`, `type`) VALUES
('config_lock_person_introduce', '设置-禁止修改个人简介', '0', '是否锁定个人简要介绍', 0),
('config_title', '通用-浏览器标题', 'Our ACM/ICPC Training Group', '浏览器标题处显示的文本', 1),
('home_chs_header', '首页-上方中文标题', '我们的ACM-ICPC集训队', '首页上方的中文标题（队名）', 2),
('home_eng_header', '首页-上方英文标题', 'Our ACM-ICPC Training Team', '首页上方的英文标题（队名）', 2),
('home_additional_title', '首页-上方附加标题', '荣誉榜', '首页上方队伍名称下面的附加标题', 2),
('home_mainarea', '首页-下方区域HTML代码', '  <div class="marketing">\n    <h1>This is a team with miracles.</h1>\n    <p class="marketing-byline">We firmly believe that hero continues !</p>\n        <hr class="soften">\n        <h2>Keep trying, keep going !</h2>\n  </div>\n', '首页奖牌数量下方至页脚上方的区域HTML代码', 2),
('config_contest_sort', '设置-获奖记录排序方法', '1', '设置每个赛季中比赛获奖记录（除World Fianl外）中的排序方法，Yes-按奖项，比赛时间依次排序，No-按比赛时间，奖项依次排序', 0),
('footer_additional_code', '页脚-附加代码', NULL, 'Footer区域附加HTML代码，可用于流量分析统计代码的添加等', 2),
('config_recent_days', '设置-首页显示最近获奖的天数', '6', '设置首页中展示最近获奖记录的天数，例如设置成1天，则展示时间为比赛获奖日期当天至下一天24时。', 1),
('config_contest_default_show', '设置-获奖记录默认展示样式', '1', '配置获奖记录默认的默认展示样式，Yes-酷炫版，No-表单版', 0),
('config_show_recent_contest', '设置-首页是否显示最近获奖记录', '0', '是否在首页中部奖牌数上方显示最近获奖记录的提醒', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
